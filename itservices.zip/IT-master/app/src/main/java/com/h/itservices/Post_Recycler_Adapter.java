package com.h.itservices;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;

import java.util.List;

import static com.h.itservices.R.*;

public class Post_Recycler_Adapter extends RecyclerView.Adapter<Post_Recycler_Adapter.MyHolder> {
    Context context;
    public List<Post> post_list;
    FirebaseAuth firebaseAuth;
    private FirebaseAuth myAccount;
    public Post_Recycler_Adapter(Context context, List<Post> post_list) {
        this.context = context;
        this.post_list = post_list;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //inflate layout single_list_item.xml
        View view = LayoutInflater.from(context).inflate(layout.single_list_item, parent, false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {
        //get data
        String description = post_list.get(position).getQuestion_text();
        String userId = post_list.get(position).getPublisher();
        String title = post_list.get(position).getQuestion_title();
        String postKey = post_list.get(position).getPostKey();
        String publisher = post_list.get(position).getPublisher();
        String time = post_list.get(position).getTime();
        String date = post_list.get(position).getDate();
        //convert time stamp to dd/mm/yyyy hh:mm am/pm
        // Calendar calendar = Calendar.getInstance(Locale.getDefault());
        //  calendar.setTimeInMillis(Long.parseLong(time));
        //  String pTime = DateFormat.format("dd/MM/yyyy hh:mm aa", calendar).toString();
        //set user image if


        //set data
        holder.post_user_name.setText(userId);
        holder.q_title.setText(title);
        holder.q_descre.setText(description);
        holder.post_time.setText(time);
        holder.q_date.setText(date);


        //handle button clicks
        holder.go_to_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "عرض التفاصيل", Toast.LENGTH_SHORT).show();
                //later
            }
        });

        holder.like.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "إعجاب", Toast.LENGTH_SHORT).show();
                //later
            }
        });

    }

    @Override
    public int getItemCount() {
        return post_list.size();
    }


    public class MyHolder extends RecyclerView.ViewHolder {
        //view from single list item
        private TextView post_user_name, q_title, q_descre, post_time, q_date, plikes;
        private Button go_to_details;
        private ImageButton like;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            //init views
            q_descre = itemView.findViewById(id.q_descre);
            post_user_name = itemView.findViewById(id.post_user_name);
            q_title = itemView.findViewById(id.q_title);
            post_time = itemView.findViewById(id.post_time);
            plikes = itemView.findViewById(id.plikes);
            go_to_details = itemView.findViewById(id.go_to_details);
            q_date=itemView.findViewById(id.q_date);;
            like = itemView.findViewById(id.like);
        }
    }
}