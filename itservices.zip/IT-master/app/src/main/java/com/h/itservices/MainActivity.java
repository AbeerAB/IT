package com.h.itservices;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.core.view.MenuItemCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.SearchView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {


    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;
    Menu menu;

    //view imp
    private FirebaseAuth mAuth;
    private RecyclerView recyclerView;
    private List<Post> post_list;
    Post_Recycler_Adapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        mAuth = FirebaseAuth.getInstance();

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent add = new Intent(MainActivity.this, Add_Question_Activity.class);
                startActivity(add);
            }
        });
        //recycler view and it's properties
        recyclerView = findViewById(R.id.postsRecyclerView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(MainActivity.this);
        //show news =t posts first , for this load from last
        layoutManager.setStackFromEnd(true);
        layoutManager.setReverseLayout(true);
        //set layout to recyclerview
        recyclerView.setLayoutManager(layoutManager);

        //init  post list
        post_list = new ArrayList<>();
        loadPosts();



        /*---------------------Hooks------------------------*/
        toolbar = findViewById(R.id.toolbar);
        navigationView = findViewById(R.id.nav_view );
        drawerLayout = findViewById(R.id.drawer_layout );
        setSupportActionBar(toolbar);
        /*---------------------Navigation------------------------*/
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        // to change color when click on item
        navigationView.setNavigationItemSelectedListener(this);
        // send this page
        navigationView.setCheckedItem(R.id.nav_home);


    }

    private void loadPosts() {
        // path of all posts
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Questions");
        //get all from this
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                post_list.clear();
                for (DataSnapshot ds: snapshot.getChildren() ){
                    Post modelPost = ds.getValue(Post.class);
                    post_list.add(modelPost);
                    //adapter
                    adapter = new Post_Recycler_Adapter(MainActivity.this,post_list);
                    //set adapter to recycler view
                    recyclerView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                //in case of error
                Toast.makeText(MainActivity.this,""+error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

        //method search later
        private void searchPosts(final String searchQuery){

            // path of all posts
            DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Questions");
            //get all from this
            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    post_list.clear();
                    for (DataSnapshot ds: snapshot.getChildren() ){
                        Post modelPost = ds.getValue(Post.class);


                        if(modelPost.getQuestion_title().toLowerCase().contains(searchQuery.toLowerCase())||
                                modelPost.getQuestion_text().toLowerCase().contains(searchQuery.toLowerCase())){
                            post_list.add(modelPost);
                        }

                        //adapter
                        adapter = new Post_Recycler_Adapter(MainActivity.this,post_list);
                        //set adapter to recycler view
                        recyclerView.setAdapter(adapter);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    //in case of error
                    Toast.makeText(MainActivity.this,""+error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });


        }

        @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            MenuInflater inflater = getMenuInflater();
            inflater.inflate(R.menu.menu, menu);

            MenuItem item = menu.findItem(R.id.serch_view);
            SearchView searchView =(SearchView) MenuItemCompat.getActionView(item);
            //search listener
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    //call when user press search button
                    if(!TextUtils.isEmpty(query)){
                        searchPosts(query);
                    }
                    else{
                        loadPosts();
                    }
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    //called as ans when user press any letter
                    if(!TextUtils.isEmpty(newText)){
                        searchPosts(newText);
                    }
                    else{
                        loadPosts();
                    }

                    return false;
                }
            });
            return true;


        }
    /*---------------------to Open or close Navigation ------------------------*/
    public void onBackPressed(){
        if(drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else
        {
            super.onBackPressed();
        }
    }
    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {

        }else {
            startActivity(new Intent(this,LoginActivity.class));
            finish();
        }

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.nav_home:break;
            case R.id.nav_profile:
                Intent profile = new Intent(MainActivity.this, ProfileActivity.class);
                startActivity(profile); break;
            case R.id.nav_MyQuestion:
                Intent MyQuestion = new Intent(MainActivity.this, MyQuestionsActivity.class);
                startActivity(MyQuestion); break;
            case R.id.nav_ExpAnswer:
                Intent Exp = new Intent(MainActivity.this, ExpertAnswersActivity.class);
                startActivity(Exp); break;
            case R.id.nav_CustomerQuestions:
                Intent home = new Intent(MainActivity.this, CustomerQuestionsActivity.class);
                startActivity(home); break;
            case R.id.nav_out:
                Intent logout = new Intent(MainActivity.this, CommentActivity.class);
                startActivity(logout); break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

}