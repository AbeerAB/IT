package com.h.itservices;

public class Post {


    private String postKey;
    private String question_title;
    private String question_text;
    private String userId;
    private String Date;
    private String Time;
    private String publisher;

    public Post(String question_title, String description, String userId, String date, String time, String publisher) {
        this.question_title = question_title;
        this.question_text = description;
        this.userId = userId;
        Date = date;
        Time = time;
        this.publisher = publisher;
    }

    // make sure to have an empty constructor inside ur model class
    public Post() {}


    public String getPostKey() {
        return postKey;
    }

    public void setPostKey(String postKey) {
        this.postKey = postKey;
    }

    public String getQuestion_title() {
        return question_title;
    }

    public void setQuestion_title(String question_title) {
        this.question_title = question_title;
    }

    public String getQuestion_text() {
        return question_text;
    }

    public void setQuestion_text(String question_text) {
        this.question_text = question_text;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }




        public Post(String question_title, String description, String userId) {
            this.question_title = question_title;
            this.question_text = description;
            //this.picture = picture;
            this.userId = userId;

        }





}
